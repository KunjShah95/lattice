import type { Metadata } from "next";
import { IBM_Plex_Mono, IBM_Plex_Sans, IBM_Plex_Serif } from "next/font/google";
import "./globals.css";

import { SearchProvider } from "@/components/search-provider";
import type { SearchEntry } from "@/lib/search";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { themeInitScript } from "@/components/theme-toggle";
import { categories } from "@/lib/data";
import { posts } from "@/lib/posts";
import { resolvedComparisons } from "@/lib/comparisons";
import { site } from "@/lib/site";

/**
 * IBM Plex — a typeface family designed for engineering and technical
 * documentation. Chosen over the Next.js default specifically because the
 * default is the single loudest "unbranded template" signal available.
 */
const plexSans = IBM_Plex_Sans({
  variable: "--font-plex-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});
const plexMono = IBM_Plex_Mono({
  variable: "--font-plex-mono",
  subsets: ["latin"],
  weight: ["400", "500"],
});
/** Serif is reserved for display type — it carries the editorial voice. */
const plexSerif = IBM_Plex_Serif({
  variable: "--font-plex-serif",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: site.defaultTitle, template: site.titleTemplate },
  description: site.description,
  openGraph: {
    type: "website",
    url: site.url,
    title: site.defaultTitle,
    description: site.description,
    siteName: site.name,
  },
  robots: { index: true, follow: true },
};

const searchEntries: SearchEntry[] = [
  // Tools
  ...categories.flatMap((c) =>
    c.tools.map((tool) => ({
      kind: "tool" as const,
      name: tool.name,
      blurb: tool.blurb,
      categoryTitle: c.title,
      categoryLayer: c.layer,
      href: `/${c.slug}/${tool.slug}`,
      external: tool.url,
      domain: tool.domain,
      tag: tool.tag,
    })),
  ),
  // Essays — the site's actual argument. Excluding these meant a query for
  // "evals" returned only tools and hid the best answer on the site.
  ...posts.map((p) => ({
    kind: "essay" as const,
    name: p.meta.title,
    blurb: p.meta.dek,
    categoryTitle: "Essays",
    categoryLayer: p.meta.layers[0] ?? null,
    href: `/blog/${p.meta.slug}`,
    tag: "Essay",
  })),
  // Comparisons
  ...resolvedComparisons.map((c) => ({
    kind: "comparison" as const,
    name: c.title,
    blurb: c.description,
    categoryTitle: "Comparisons",
    categoryLayer: c.tools[0]?.layer ?? null,
    href: `/compare/${c.slug}`,
    tag: "Compared",
  })),
];

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={`${plexSans.variable} ${plexMono.variable} ${plexSerif.variable} h-full antialiased`}
    >
      <head>
        {/* Applies the stored/system theme before first paint. */}
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body className="flex min-h-full flex-col">
        <SearchProvider entries={searchEntries}>
          <SiteHeader />
          <main className="flex-1">{children}</main>
          <SiteFooter />
        </SearchProvider>
      </body>
    </html>
  );
}
